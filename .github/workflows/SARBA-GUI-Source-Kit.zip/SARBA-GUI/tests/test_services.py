import os
import tempfile
import unittest
import time
from pathlib import Path
from unittest.mock import patch

from app import services


class ServiceTests(unittest.TestCase):
    def test_temp_cleaner_removes_only_temp_contents(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "temp"
            root.mkdir()
            old_file = root / "old.tmp"
            old_file.write_text("temp payload", encoding="utf-8")
            nested = root / "nested"
            nested.mkdir()
            nested_file = nested / "nested.tmp"
            nested_file.write_text("nested temp", encoding="utf-8")
            outside = Path(tmp) / "keep.txt"
            outside.write_text("keep", encoding="utf-8")
            with patch.dict(os.environ, {"TEMP": str(root), "TMP": str(root)}):
                result = services.clean_user_temp(max_age_hours=0)
            self.assertEqual(result.files_removed, 2)
            self.assertFalse(old_file.exists())
            self.assertFalse(nested_file.exists())
            self.assertTrue(outside.exists())
            self.assertGreater(result.bytes_freed, 0)

    def test_telemetry_does_not_fabricate_fps(self):
        telemetry = services.Telemetry()
        data = telemetry.sample(fps=None, fps_status="No FPS process selected")
        self.assertIsNone(data.fps)
        self.assertEqual(data.fps_status, "No FPS process selected")
        self.assertGreaterEqual(data.ram_percent, 0)
        self.assertLessEqual(data.ram_percent, 100)

    def test_settings_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"APPDATA": tmp}):
            services.save_settings({"auto_clean_temp": True, "fps_process_name": "HD-Player.exe", "games": []})
            loaded = services.load_settings()
            self.assertTrue(loaded["auto_clean_temp"])
            self.assertEqual(loaded["fps_process_name"], "HD-Player.exe")

    def test_presentmon_csv_reports_frame_rate_without_guessing(self):
        with tempfile.TemporaryDirectory() as tmp:
            capture = Path(tmp) / "capture.csv"
            capture.write_text(
                "Application,MsBetweenPresents,MsBetweenDisplayChange\n"
                "test.exe,16.6667,16.6667\n"
                "test.exe,16.6667,16.6667\n"
                "test.exe,16.6667,16.6667\n",
                encoding="utf-8",
            )
            monitor = services.PresentMonFPS()
            monitor.csv_path = capture
            monitor.status = "Capturing"
            monitor._started = time.monotonic()
            fps, status = monitor.read_fps()
            self.assertAlmostEqual(fps, 60.0, delta=0.5)
            self.assertIn("PresentMon", status)

    def test_empty_presentmon_csv_keeps_fps_unavailable(self):
        with tempfile.TemporaryDirectory() as tmp:
            capture = Path(tmp) / "empty.csv"
            capture.write_text("Application,MsBetweenPresents\n", encoding="utf-8")
            monitor = services.PresentMonFPS()
            monitor.csv_path = capture
            monitor.status = "No frame events"
            monitor._started = time.monotonic()
            fps, _status = monitor.read_fps()
            self.assertIsNone(fps)

    def test_game_detector_returns_well_formed_list(self):
        games = services.detect_games()
        self.assertIsInstance(games, list)
        for game in games:
            self.assertTrue(game["name"])
            self.assertTrue(game["path"])
            self.assertTrue(game["category"])

    def test_fan_api_is_explicitly_unavailable_off_windows(self):
        if os.name != "nt":
            fan = services.NvidiaFanControl()
            self.assertFalse(fan.gpu_handles)
            self.assertIn("Windows", fan.status)


if __name__ == "__main__":
    unittest.main()
